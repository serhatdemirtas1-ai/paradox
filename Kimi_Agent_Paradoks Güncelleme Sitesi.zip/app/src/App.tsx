import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import Hero from './sections/Hero';
import Categories from './sections/Categories';
import DailyParadox from './sections/DailyParadox';
import ParadoxStream from './sections/ParadoxStream';
import QuoteWall from './sections/QuoteWall';
import Subscribe from './sections/Subscribe';
import Footer from './sections/Footer';
import ParticleBackground from './components/ParticleBackground';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const lenisRef = useRef<Lenis | null>(null);

  useEffect(() => {
    // Initialize Lenis smooth scroll
    lenisRef.current = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      smoothWheel: true,
    });

    function raf(time: number) {
      lenisRef.current?.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    // Connect Lenis to ScrollTrigger
    lenisRef.current.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      lenisRef.current?.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);

    return () => {
      lenisRef.current?.destroy();
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <div className="relative min-h-screen bg-[#050507] text-[#e2e8f0] overflow-x-hidden">
      {/* Particle Background */}
      <ParticleBackground />
      
      {/* Noise Overlay */}
      <div className="noise-overlay" />
      
      {/* Main Content */}
      <main className="relative z-10">
        <Hero />
        <Categories />
        <DailyParadox />
        <ParadoxStream />
        <QuoteWall />
        <Subscribe />
        <Footer />
      </main>
    </div>
  );
}

export default App;
