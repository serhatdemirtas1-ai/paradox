import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const quotes = [
  {
    text: "Bildiğim tek şey, hiçbir şey bilmediğimdir.",
    author: "Sokrates",
    year: "MÖ 470-399",
  },
  {
    text: "Tanrı zar atmaz.",
    author: "Albert Einstein",
    year: "1879-1955",
  },
  {
    text: "Düşünüyorum, öyleyse varım.",
    author: "René Descartes",
    year: "1596-1650",
  },
  {
    text: "Gerçeklik, bir yanılsama olabilir mi?",
    author: "Platon",
    year: "MÖ 428-348",
  },
  {
    text: "Zaman, her şeyin ilacıdır.",
    author: "Thales",
    year: "MÖ 624-546",
  },
  {
    text: "Sonsuzluk, sınırların ötesindedir.",
    author: "Georg Cantor",
    year: "1845-1918",
  },
  {
    text: "Mantık, mantıksızlığın içinde yatar.",
    author: "Ludwig Wittgenstein",
    year: "1889-1951",
  },
  {
    text: "Evren, bir bilmece değil, bir gizemdir.",
    author: "Arthur Eddington",
    year: "1882-1944",
  },
];

export default function QuoteWall() {
  const sectionRef = useRef<HTMLElement>(null);
  const marquee1Ref = useRef<HTMLDivElement>(null);
  const marquee2Ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Speed up on scroll
      gsap.to('.marquee', {
        animationDuration: '5s',
        scrollTrigger: {
          trigger: section,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1,
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="quote-wall"
      className="relative py-24 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050507] via-[#0a0a1a] to-[#050507]" />
      
      {/* Section Header */}
      <div className="relative z-10 text-center mb-16 px-4">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
          <span className="text-gradient">Düşünce</span>{' '}
          <span className="text-white">Yankıları</span>
        </h2>
        <p className="text-slate-400 text-lg max-w-2xl mx-auto">
          Felsefe ve bilim tarihinden seçilmiş alıntılar
        </p>
      </div>

      {/* Marquee Rows */}
      <div className="relative space-y-8">
        {/* Row 1 - Left to Right */}
        <div className="relative overflow-hidden">
          <div
            ref={marquee1Ref}
            className="marquee flex gap-8 whitespace-nowrap"
          >
            {[...quotes, ...quotes].map((quote, index) => (
              <div
                key={index}
                className="inline-flex flex-col px-8 py-6 rounded-2xl glass min-w-[400px]"
              >
                <p className="text-xl sm:text-2xl font-medium text-white mb-4 whitespace-normal">
                  "{quote.text}"
                </p>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-purple-400">{quote.author}</span>
                  <span className="text-slate-500">{quote.year}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Row 2 - Right to Left */}
        <div className="relative overflow-hidden">
          <div
            ref={marquee2Ref}
            className="marquee-reverse flex gap-8 whitespace-nowrap"
          >
            {[...quotes.slice().reverse(), ...quotes.slice().reverse()].map((quote, index) => (
              <div
                key={index}
                className="inline-flex flex-col px-8 py-6 rounded-2xl glass min-w-[400px]"
              >
                <p className="text-xl sm:text-2xl font-medium text-white mb-4 whitespace-normal">
                  "{quote.text}"
                </p>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-purple-400">{quote.author}</span>
                  <span className="text-slate-500">{quote.year}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Row 3 - Left to Right (different speed) */}
        <div className="relative overflow-hidden opacity-50">
          <div
            className="marquee flex gap-8 whitespace-nowrap"
            style={{ animationDuration: '40s' }}
          >
            {[...quotes.slice(2), ...quotes.slice(0, 2), ...quotes.slice(2), ...quotes.slice(0, 2)].map((quote, index) => (
              <div
                key={index}
                className="inline-flex flex-col px-6 py-4 rounded-xl glass min-w-[300px]"
              >
                <p className="text-lg font-medium text-slate-300 mb-2 whitespace-normal">
                  "{quote.text}"
                </p>
                <span className="text-xs text-slate-500">{quote.author}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Gradient overlays for fade effect */}
      <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-[#050507] to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-[#050507] to-transparent z-10 pointer-events-none" />
    </section>
  );
}
