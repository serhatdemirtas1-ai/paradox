import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { categories, type Category } from '../data/paradoxes';
import { Brain, Calculator, Atom, Puzzle, Clock, Infinity } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const iconMap: Record<Category, React.ReactNode> = {
  all: <Infinity className="w-8 h-8" />,
  philosophy: <Brain className="w-8 h-8" />,
  mathematics: <Calculator className="w-8 h-8" />,
  physics: <Atom className="w-8 h-8" />,
  logic: <Puzzle className="w-8 h-8" />,
  time: <Clock className="w-8 h-8" />,
};

interface CategoriesProps {
  selectedCategory?: Category;
  onCategoryChange?: (category: Category) => void;
}

export default function Categories({ selectedCategory = 'all', onCategoryChange }: CategoriesProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const cards = cardsRef.current;
    if (!section || !cards) return;

    const ctx = gsap.context(() => {
      const cardElements = cards.querySelectorAll('.category-card');

      gsap.set(cardElements, {
        opacity: 0,
        z: -500,
        transformPerspective: 1000,
      });

      gsap.to(cardElements, {
        opacity: 1,
        z: 0,
        duration: 1,
        stagger: 0.1,
        ease: 'expo.out',
        scrollTrigger: {
          trigger: section,
          start: 'top 70%',
          toggleActions: 'play none none reverse',
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  const handleCategoryClick = (categoryId: Category) => {
    onCategoryChange?.(categoryId);
    
    // Scroll to paradox stream
    const streamSection = document.getElementById('paradox-stream');
    if (streamSection) {
      streamSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="categories"
      className="relative py-24 px-4 sm:px-6 lg:px-8"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            <span className="text-gradient">Labirentin</span>{' '}
            <span className="text-white">Kapıları</span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Her kategori, farklı bir düşünce dünyasının kapısını aralar.
            Hangi paradoksla başlamak istersin?
          </p>
        </div>

        {/* Category Cards */}
        <div
          ref={cardsRef}
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6"
        >
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => handleCategoryClick(category.id)}
              className={`category-card group relative p-6 rounded-2xl glass transition-all duration-500 hover:scale-105 hover:shadow-[0_0_30px_rgba(109,40,217,0.3)] ${
                selectedCategory === category.id
                  ? 'ring-2 ring-purple-500 shadow-[0_0_30px_rgba(109,40,217,0.4)]'
                  : ''
              }`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              {/* Hover glow effect */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-purple-600/20 to-indigo-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              {/* Content */}
              <div className="relative z-10 flex flex-col items-center">
                <div className="mb-4 text-purple-400 group-hover:text-purple-300 group-hover:scale-110 transition-all duration-300">
                  {iconMap[category.id]}
                </div>
                <span className="text-sm font-medium text-slate-300 group-hover:text-white transition-colors">
                  {category.name}
                </span>
              </div>

              {/* Corner decoration */}
              <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-purple-500/50 opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          ))}
        </div>

        {/* Decorative line */}
        <div className="mt-16 flex justify-center">
          <div className="w-32 h-px bg-gradient-to-r from-transparent via-purple-500/50 to-transparent" />
        </div>
      </div>
    </section>
  );
}
