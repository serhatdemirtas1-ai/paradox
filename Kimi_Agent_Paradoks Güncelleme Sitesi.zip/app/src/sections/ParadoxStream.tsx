import { useEffect, useRef, useState, useMemo } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { paradoxes, categories, getParadoxesByCategory, searchParadoxes, type Category, type Paradox } from '../data/paradoxes';
import { Search, Filter, ArrowRight, X, Sparkles } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';

gsap.registerPlugin(ScrollTrigger);

export default function ParadoxStream() {
  const sectionRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const [selectedCategory, setSelectedCategory] = useState<Category>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedParadox, setSelectedParadox] = useState<Paradox | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const filteredParadoxes = useMemo(() => {
    let result = paradoxes;
    
    if (selectedCategory !== 'all') {
      result = getParadoxesByCategory(selectedCategory);
    }
    
    if (searchQuery.trim()) {
      result = searchParadoxes(searchQuery);
      if (selectedCategory !== 'all') {
        result = result.filter(p => p.category === selectedCategory);
      }
    }
    
    return result;
  }, [selectedCategory, searchQuery]);

  useEffect(() => {
    const section = sectionRef.current;
    const grid = gridRef.current;
    if (!section || !grid) return;

    const ctx = gsap.context(() => {
      const cards = grid.querySelectorAll('.paradox-card');

      gsap.set(cards, {
        opacity: 0,
        y: 100,
      });

      gsap.to(cards, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.05,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: section,
          start: 'top 70%',
          toggleActions: 'play none none reverse',
        },
      });
    }, section);

    return () => ctx.revert();
  }, [filteredParadoxes]);

  const handleParadoxClick = (paradox: Paradox) => {
    setSelectedParadox(paradox);
    setDialogOpen(true);
  };

  const clearSearch = () => {
    setSearchQuery('');
  };

  return (
    <>
      <section
        ref={sectionRef}
        id="paradox-stream"
        className="relative py-24 px-4 sm:px-6 lg:px-8"
      >
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              <span className="text-gradient">Paradoks</span>{' '}
              <span className="text-white">Akışı</span>
            </h2>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto">
              Tüm paradoksları keşfedin. Her biri farklı bir bakış açısı sunar.
            </p>
          </div>

          {/* Search and Filter */}
          <div className="mb-12 space-y-6">
            {/* Search */}
            <div className="relative max-w-md mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input
                type="text"
                placeholder="Paradoks ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-12 py-3 rounded-full bg-white/5 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500/50 focus:ring-2 focus:ring-purple-500/20 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={clearSearch}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap justify-center gap-2">
              <div className="flex items-center gap-2 mr-4 text-slate-500">
                <Filter className="w-4 h-4" />
                <span className="text-sm">Filtre:</span>
              </div>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-full text-sm transition-all duration-300 ${
                    selectedCategory === cat.id
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_20px_rgba(109,40,217,0.4)]'
                      : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Results count */}
          <div className="mb-6 text-center text-sm text-slate-500">
            {filteredParadoxes.length} paradoks bulundu
          </div>

          {/* Paradox Grid */}
          <div
            ref={gridRef}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredParadoxes.map((paradox) => (
              <div
                key={paradox.id}
                onClick={() => handleParadoxClick(paradox)}
                className="paradox-card group relative rounded-2xl overflow-hidden glass cursor-pointer"
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={paradox.image}
                    alt={paradox.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-transparent to-transparent" />
                  
                  {/* Category badge */}
                  <div className="absolute top-4 left-4 px-3 py-1 rounded-full glass text-xs text-purple-300">
                    {categories.find(c => c.id === paradox.category)?.name}
                  </div>
                  
                  {/* Difficulty indicator */}
                  <div className="absolute top-4 right-4 flex gap-1">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div
                        key={i}
                        className={`w-2 h-2 rounded-full ${
                          i < (paradox.difficulty === 'easy' ? 1 : paradox.difficulty === 'medium' ? 2 : 3)
                            ? 'bg-purple-500'
                            : 'bg-white/20'
                        }`}
                      />
                    ))}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">
                    {paradox.title}
                  </h3>
                  <p className="text-slate-400 text-sm line-clamp-2 mb-4">
                    {paradox.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500">{paradox.year}</span>
                    <span className="inline-flex items-center gap-1 text-sm text-purple-400 group-hover:text-purple-300 transition-colors">
                      <span>Keşfet</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </div>
                </div>

                {/* Hover glow */}
                <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                  <div className="absolute inset-0 rounded-2xl shadow-[inset_0_0_30px_rgba(109,40,217,0.2)]" />
                </div>
              </div>
            ))}
          </div>

          {/* Empty state */}
          {filteredParadoxes.length === 0 && (
            <div className="text-center py-20">
              <Sparkles className="w-12 h-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-500">Sonuç bulunamadı.</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                }}
                className="mt-4 text-purple-400 hover:text-purple-300 transition-colors"
              >
                Filtreleri temizle
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Paradox Detail Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto bg-[#0a0a0f] border-purple-500/20">
          {selectedParadox && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold text-gradient">
                  {selectedParadox.title}
                </DialogTitle>
                <DialogDescription className="text-slate-400">
                  {selectedParadox.titleEn}
                </DialogDescription>
              </DialogHeader>
              
              <div className="mt-4 space-y-6">
                <img
                  src={selectedParadox.image}
                  alt={selectedParadox.title}
                  className="w-full h-56 object-cover rounded-xl"
                />
                
                <div className="flex flex-wrap items-center gap-3">
                  <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-sm">
                    {categories.find(c => c.id === selectedParadox.category)?.name}
                  </span>
                  <span className="text-sm text-slate-500">{selectedParadox.origin}</span>
                  <span className="text-sm text-slate-500">{selectedParadox.year}</span>
                  <span className={`px-3 py-1 rounded-full text-xs capitalize ${
                    selectedParadox.difficulty === 'easy' 
                      ? 'bg-green-500/20 text-green-300'
                      : selectedParadox.difficulty === 'medium'
                      ? 'bg-yellow-500/20 text-yellow-300'
                      : 'bg-red-500/20 text-red-300'
                  }`}>
                    {selectedParadox.difficulty === 'easy' ? 'Kolay' : selectedParadox.difficulty === 'medium' ? 'Orta' : 'Zor'}
                  </span>
                </div>
                
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">Özet</h4>
                  <p className="text-slate-300 leading-relaxed">
                    {selectedParadox.description}
                  </p>
                </div>
                
                <div className="p-6 rounded-xl bg-white/5 border border-white/10">
                  <h4 className="text-lg font-semibold text-white mb-3">Detaylı Açıklama</h4>
                  <p className="text-slate-400 leading-relaxed">
                    {selectedParadox.explanation}
                  </p>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
