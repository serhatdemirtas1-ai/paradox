import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronDown, Sparkles } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const [glitchActive, setGlitchActive] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const subtitle = subtitleRef.current;
    const cta = ctaRef.current;

    if (!section || !title || !subtitle || !cta) return;

    const ctx = gsap.context(() => {
      // Initial states
      gsap.set(title, { opacity: 0, rotateX: 90, transformOrigin: 'center bottom' });
      gsap.set(subtitle, { opacity: 0, filter: 'blur(10px)', y: 20 });
      gsap.set(cta, { opacity: 0, scale: 0 });

      // Entry animation timeline
      const tl = gsap.timeline({ delay: 0.3 });

      tl.to(title, {
        opacity: 1,
        rotateX: 0,
        duration: 1.5,
        ease: 'expo.out',
      })
        .to(
          subtitle,
          {
            opacity: 1,
            filter: 'blur(0px)',
            y: 0,
            duration: 1.2,
            ease: 'power2.out',
          },
          '-=0.9'
        )
        .to(
          cta,
          {
            opacity: 1,
            scale: 1,
            duration: 0.8,
            ease: 'elastic.out(1, 0.5)',
          },
          '-=0.5'
        );

      // Scroll parallax
      gsap.to(title, {
        y: -150,
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: 'bottom top',
          scrub: 1,
        },
      });

      // Background zoom on scroll
      gsap.to('.hero-bg', {
        scale: 1.2,
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: 'bottom top',
          scrub: 1,
        },
      });
    }, section);

    // Glitch effect interval
    const glitchInterval = setInterval(() => {
      setGlitchActive(true);
      setTimeout(() => setGlitchActive(false), 300);
    }, 4000);

    return () => {
      ctx.revert();
      clearInterval(glitchInterval);
    };
  }, []);

  const scrollToContent = () => {
    const categoriesSection = document.getElementById('categories');
    if (categoriesSection) {
      categoriesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background */}
      <div className="hero-bg absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-gradient-to-br from-[#0a0a0f] via-[#1a0a2e] to-[#0f0a1a]"
        />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(109,40,217,0.15)_0%,_transparent_70%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(99,102,241,0.1)_0%,_transparent_50%)]" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8 opacity-0 animate-[fadeInUp_0.8s_ease-out_0.1s_forwards]">
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span className="text-sm text-purple-200">Düşünce Deneyleri Koleksiyonu</span>
        </div>

        {/* Title */}
        <h1
          ref={titleRef}
          className={`text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold mb-6 tracking-tight ${
            glitchActive ? 'glitch active' : ''
          }`}
          data-text="PARADOKS VAULT"
          style={{ perspective: '1000px' }}
        >
          <span className="text-gradient">PARADOKS</span>
          <br />
          <span className="text-white">VAULT</span>
        </h1>

        {/* Subtitle */}
        <p
          ref={subtitleRef}
          className="text-lg sm:text-xl md:text-2xl text-slate-400 max-w-2xl mx-auto mb-12 leading-relaxed"
        >
          Gerçekliği sorgulayan düşünce deneyleri koleksiyonu.
          <br className="hidden sm:block" />
          Mantığınızı zorlayacak paradokslarla tanışın.
        </p>

        {/* CTA Button */}
        <button
          ref={ctaRef}
          onClick={scrollToContent}
          className="group relative inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full text-white font-semibold text-lg transition-all duration-300 hover:shadow-[0_0_40px_rgba(109,40,217,0.5)] hover:scale-105"
        >
          <span>KEŞFET</span>
          <ChevronDown className="w-5 h-5 group-hover:translate-y-1 transition-transform" />
        </button>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-3 gap-8 max-w-lg mx-auto opacity-0 animate-[fadeInUp_0.8s_ease-out_1.2s_forwards]">
          <div className="text-center">
            <div className="text-3xl sm:text-4xl font-bold text-gradient">18+</div>
            <div className="text-sm text-slate-500 mt-1">Paradoks</div>
          </div>
          <div className="text-center">
            <div className="text-3xl sm:text-4xl font-bold text-gradient">6</div>
            <div className="text-sm text-slate-500 mt-1">Kategori</div>
          </div>
          <div className="text-center">
            <div className="text-3xl sm:text-4xl font-bold text-gradient">∞</div>
            <div className="text-sm text-slate-500 mt-1">Soru</div>
          </div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#050507] to-transparent z-10" />
    </section>
  );
}
