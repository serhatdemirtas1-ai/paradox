import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { getDailyParadox } from '../data/paradoxes';
import { Calendar, Sparkles, ArrowRight } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';

gsap.registerPlugin(ScrollTrigger);

export default function DailyParadox() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftPanelRef = useRef<HTMLDivElement>(null);
  const rightPanelRef = useRef<HTMLDivElement>(null);
  const dividerRef = useRef<HTMLDivElement>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  
  const dailyParadox = getDailyParadox();

  useEffect(() => {
    const section = sectionRef.current;
    const leftPanel = leftPanelRef.current;
    const rightPanel = rightPanelRef.current;
    const divider = dividerRef.current;

    if (!section || !leftPanel || !rightPanel || !divider) return;

    const ctx = gsap.context(() => {
      // Initial states
      gsap.set(leftPanel, { x: '-100%', opacity: 0 });
      gsap.set(rightPanel, { x: '100%', opacity: 0 });
      gsap.set(divider, { height: '0%' });

      // Entry animation
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top 60%',
          toggleActions: 'play none none reverse',
        },
      });

      tl.to(leftPanel, {
        x: '0%',
        opacity: 1,
        duration: 1,
        ease: 'power3.out',
      })
        .to(
          rightPanel,
          {
            x: '0%',
            opacity: 1,
            duration: 1,
            ease: 'power3.out',
          },
          '<'
        )
        .to(
          divider,
          {
            height: '100%',
            duration: 1.2,
            ease: 'power2.out',
          },
          '-=0.5'
        );

      // Scroll effects
      gsap.to(leftPanel.querySelector('.content'), {
        opacity: 0,
        scrollTrigger: {
          trigger: section,
          start: 'center center',
          end: 'bottom center',
          scrub: 1,
        },
      });

      gsap.to(rightPanel.querySelector('img'), {
        scale: 1.2,
        scrollTrigger: {
          trigger: section,
          start: 'center center',
          end: 'bottom center',
          scrub: 1,
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <>
      <section
        ref={sectionRef}
        id="daily-paradox"
        className="relative min-h-screen py-24 overflow-hidden"
      >
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#050507] via-[#0a0a1a] to-[#050507]" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6">
              <Calendar className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-purple-200">{dailyParadox.date}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold">
              <span className="text-gradient">Günün</span>{' '}
              <span className="text-white">Paradoksu</span>
            </h2>
          </div>

          {/* Split Layout */}
          <div className="relative flex flex-col lg:flex-row min-h-[600px] rounded-3xl overflow-hidden glass">
            {/* Left Panel - Text */}
            <div
              ref={leftPanelRef}
              className="flex-1 p-8 sm:p-12 flex flex-col justify-center"
            >
              <div className="content">
                <div className="flex items-center gap-2 mb-6">
                  <Sparkles className="w-5 h-5 text-purple-400" />
                  <span className="text-sm text-purple-300 uppercase tracking-wider">
                    {dailyParadox.category}
                  </span>
                </div>

                <h3 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                  {dailyParadox.title}
                </h3>

                <p className="text-lg text-slate-300 mb-6 leading-relaxed">
                  {dailyParadox.description}
                </p>

                <p className="text-slate-400 mb-8 leading-relaxed">
                  {dailyParadox.explanation.substring(0, 200)}...
                </p>

                <button
                  onClick={() => setDialogOpen(true)}
                  className="group inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors"
                >
                  <span>Devamını Oku</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* Meta info */}
                <div className="mt-12 pt-6 border-t border-white/10 flex items-center gap-6 text-sm text-slate-500">
                  <span>Köken: {dailyParadox.origin}</span>
                  <span>Yıl: {dailyParadox.year}</span>
                  <span className="capitalize">Zorluk: {dailyParadox.difficulty}</span>
                </div>
              </div>
            </div>

            {/* Divider */}
            <div
              ref={dividerRef}
              className="hidden lg:block w-px bg-gradient-to-b from-transparent via-purple-500/50 to-transparent"
            />

            {/* Right Panel - Image */}
            <div
              ref={rightPanelRef}
              className="flex-1 relative min-h-[300px] lg:min-h-0"
            >
              <div className="absolute inset-0 overflow-hidden">
                <img
                  src={dailyParadox.image}
                  alt={dailyParadox.title}
                  className="w-full h-full object-cover"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#050507] via-transparent to-transparent lg:bg-gradient-to-l" />
              </div>

              {/* Floating badge */}
              <div className="absolute bottom-6 right-6 px-4 py-2 rounded-full glass">
                <span className="text-sm text-purple-200">Günlük Seçim</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-[#0a0a0f] border-purple-500/20">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-gradient">
              {dailyParadox.title}
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              {dailyParadox.titleEn}
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-4 space-y-4">
            <img
              src={dailyParadox.image}
              alt={dailyParadox.title}
              className="w-full h-48 object-cover rounded-xl"
            />
            
            <div className="flex items-center gap-4 text-sm text-slate-500">
              <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-300">
                {dailyParadox.category}
              </span>
              <span>{dailyParadox.origin}</span>
              <span>{dailyParadox.year}</span>
            </div>
            
            <p className="text-slate-300 leading-relaxed">
              {dailyParadox.description}
            </p>
            
            <div className="p-4 rounded-xl bg-white/5 border border-white/10">
              <h4 className="text-lg font-semibold text-white mb-2">Açıklama</h4>
              <p className="text-slate-400 leading-relaxed">
                {dailyParadox.explanation}
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
