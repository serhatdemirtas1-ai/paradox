import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Send, CheckCircle, Sparkles } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function Subscribe() {
  const sectionRef = useRef<HTMLElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const lightRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [focused, setFocused] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    const form = formRef.current;
    const light = lightRef.current;

    if (!section || !form || !light) return;

    const ctx = gsap.context(() => {
      gsap.set(form, { opacity: 0 });
      gsap.set(light, { width: '0%' });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top 70%',
          toggleActions: 'play none none reverse',
        },
      });

      tl.to(form, {
        opacity: 1,
        duration: 1,
        ease: 'power2.out',
      }).to(
        light,
        {
          width: '100%',
          duration: 1.5,
          ease: 'power3.out',
        },
        '-=0.5'
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setEmail('');
      }, 3000);
    }
  };

  return (
    <section
      ref={sectionRef}
      id="subscribe"
      className="relative py-32 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050507] via-[#0a0a1a] to-[#050507]" />
      
      {/* Light beam effect */}
      <div
        ref={lightRef}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[600px] bg-gradient-to-b from-purple-500/10 via-purple-500/5 to-transparent blur-3xl pointer-events-none"
        style={{ width: '0%' }}
      />

      <div className="relative z-10 max-w-xl mx-auto text-center">
        {/* Icon */}
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full glass mb-8 pulse-glow">
          <Mail className="w-8 h-8 text-purple-400" />
        </div>

        {/* Title */}
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
          <span className="text-gradient">Sırlara</span>{' '}
          <span className="text-white">Eriş</span>
        </h2>

        <p className="text-slate-400 text-lg mb-12">
          Her gün yeni bir paradoks doğrudan gelen kutunuza gelsin.
          Düşünce dünyanızı genişletin.
        </p>

        {/* Form */}
        <form
          ref={formRef}
          onSubmit={handleSubmit}
          className="relative"
        >
          <div
            className={`relative flex flex-col sm:flex-row gap-4 p-2 rounded-2xl glass transition-all duration-500 ${
              focused ? 'shadow-[0_0_30px_rgba(109,40,217,0.3)]' : ''
            }`}
          >
            <div className="relative flex-1">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onFocus={() => setFocused(true)}
                onBlur={() => setFocused(false)}
                placeholder="E-posta adresiniz..."
                disabled={submitted}
                className="w-full px-6 py-4 bg-transparent text-white placeholder-slate-500 focus:outline-none disabled:opacity-50"
              />
            </div>
            
            <button
              type="submit"
              disabled={submitted || !email}
              className={`group flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-semibold transition-all duration-300 ${
                submitted
                  ? 'bg-green-600 text-white'
                  : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:shadow-[0_0_30px_rgba(109,40,217,0.5)] disabled:opacity-50 disabled:cursor-not-allowed'
              }`}
            >
              {submitted ? (
                <>
                  <CheckCircle className="w-5 h-5" />
                  <span>Kaydedildi</span>
                </>
              ) : (
                <>
                  <span>ANAHTARI AL</span>
                  <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </div>

          {/* Decorative sparkles */}
          <div className="absolute -top-4 -right-4 text-purple-400/50">
            <Sparkles className="w-6 h-6" />
          </div>
          <div className="absolute -bottom-4 -left-4 text-purple-400/50">
            <Sparkles className="w-6 h-6" />
          </div>
        </form>

        {/* Trust indicators */}
        <div className="mt-8 flex flex-wrap justify-center gap-6 text-sm text-slate-500">
          <span className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            Günlük güncellemeler
          </span>
          <span className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            Spam yok
          </span>
          <span className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            İstediğiniz zaman iptal
          </span>
        </div>
      </div>
    </section>
  );
}
