import { useEffect, useRef } from 'react';
import { Brain, Github, Twitter, Instagram, Linkedin, Heart } from 'lucide-react';

export default function Footer() {
  const globeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const globe = globeRef.current;
    if (!globe) return;

    // Continuous rotation
    let rotation = 0;
    const animate = () => {
      rotation += 0.2;
      globe.style.transform = `rotate(${rotation}deg)`;
      requestAnimationFrame(animate);
    };

    const animationId = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationId);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="relative py-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[#050507]" />
      
      {/* Wireframe globe */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 opacity-5">
        <div
          ref={globeRef}
          className="w-96 h-96 rounded-full border border-white/20"
          style={{
            background: `
              radial-gradient(circle at 30% 30%, transparent 40%, rgba(255,255,255,0.1) 41%, transparent 42%),
              radial-gradient(circle at 70% 70%, transparent 40%, rgba(255,255,255,0.1) 41%, transparent 42%),
              linear-gradient(0deg, transparent 49%, rgba(255,255,255,0.1) 50%, transparent 51%),
              linear-gradient(60deg, transparent 49%, rgba(255,255,255,0.1) 50%, transparent 51%),
              linear-gradient(120deg, transparent 49%, rgba(255,255,255,0.1) 50%, transparent 51%)
            `,
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Paradoks Vault</span>
            </div>
            <p className="text-slate-400 max-w-sm mb-6">
              Gerçekliği sorgulayan düşünce deneyleri koleksiyonu. 
              Mantığınızı zorlayacak paradokslarla tanışın.
            </p>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-all"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-all"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-all"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-all"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Hızlı Bağlantılar</h4>
            <ul className="space-y-3">
              <li>
                <button
                  onClick={() => scrollToSection('categories')}
                  className="text-slate-400 hover:text-purple-400 transition-colors"
                >
                  Kategoriler
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('daily-paradox')}
                  className="text-slate-400 hover:text-purple-400 transition-colors"
                >
                  Günün Paradoksu
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('paradox-stream')}
                  className="text-slate-400 hover:text-purple-400 transition-colors"
                >
                  Tüm Paradokslar
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('subscribe')}
                  className="text-slate-400 hover:text-purple-400 transition-colors"
                >
                  Abone Ol
                </button>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-white font-semibold mb-4">Kategoriler</h4>
            <ul className="space-y-3">
              <li>
                <span className="text-slate-400">Felsefe</span>
              </li>
              <li>
                <span className="text-slate-400">Matematik</span>
              </li>
              <li>
                <span className="text-slate-400">Fizik</span>
              </li>
              <li>
                <span className="text-slate-400">Mantık</span>
              </li>
              <li>
                <span className="text-slate-400">Zaman</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-sm">
            © 2025 Paradoks Vault. Tüm hakları saklıdır.
          </p>
          <p className="text-slate-500 text-sm flex items-center gap-1">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-red-500 fill-red-500" />
            <span>for curious minds</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
