export type Category = 'all' | 'philosophy' | 'mathematics' | 'physics' | 'logic' | 'time';

export interface Paradox {
  id: string;
  title: string;
  titleEn: string;
  description: string;
  explanation: string;
  category: Category;
  image: string;
  date?: string;
  difficulty: 'easy' | 'medium' | 'hard';
  origin: string;
  year: string;
}

export const categories = [
  { id: 'all' as Category, name: 'Tümü', icon: '∞' },
  { id: 'philosophy' as Category, name: 'Felsefe', icon: '🏛️' },
  { id: 'mathematics' as Category, name: 'Matematik', icon: '∑' },
  { id: 'physics' as Category, name: 'Fizik', icon: '⚛️' },
  { id: 'logic' as Category, name: 'Mantık', icon: '🧠' },
  { id: 'time' as Category, name: 'Zaman', icon: '⏰' },
];

export const paradoxes: Paradox[] = [
  {
    id: 'schrodinger-cat',
    title: "Schrödinger'in Kedisi",
    titleEn: "Schrödinger's Cat",
    description: "Bir kutu açılana kadar kedi hem ölü hem canlıdır. Kuantum mekaniğinin en ünlü düşünce deneyi.",
    explanation: "Schrödinger'in kedisi paradoksu, 1935'te Erwin Schrödinger tarafından ortaya atılmıştır. Bir kutuya konan kedi, radyoaktif bir maddenin rastgele bozunmasıyla zehirli bir şişenin kırılmasına bağlı olarak hem ölü hem canlı durumunda olabilir. Kuantum süperpozisyonu ilkesine göre, gözlem yapılana kadar sistem her iki durumda birden bulunur. Bu paradoks, kuantum mekaniğinin makroskopik dünyaya uygulanmasındaki problemleri gösterir.",
    category: 'physics',
    image: 'https://kimi-web-img.moonshot.cn/img/datavizblog.com/4e88cc2676927c6acc29eee6c246c9114f3d5dcf.jpg',
    difficulty: 'hard',
    origin: 'Erwin Schrödinger',
    year: '1935'
  },
  {
    id: 'zeno-turtle',
    title: "Zeno'nun Kaplumbağası",
    titleEn: "Zeno's Tortoise",
    description: "Hızlı koşan Aşil, yavaş kaplumbağayı asla geçemez. Hareketin imkansız olduğunu mu söylüyor?",
    explanation: "Elealı Zeno (MÖ 490-430), Parmenides'in öğrencisi olarak hareketin bir yanılsama olduğunu savunmuştur. Aşil ve Kaplumbağa paradoksunda, Aşil kaplumbağaya başlangıç avantajı verir. Aşil kaplumbağanın başlangıç noktasına ulaştığında, kaplumbağa biraz ilerlemiş olur. Bu sonsuza kadar devam eder gibi görünür. Ancak modern matematikte sonsuz serilerin toplamı sonlu olabilir (1/2 + 1/4 + 1/8 + ... = 1). Bu paradoks, limit kavramının gelişimine katkıda bulunmuştur.",
    category: 'mathematics',
    image: 'https://images.unsplash.com/photo-1437622368342-7a3d73a34c8f?w=800&q=80',
    difficulty: 'medium',
    origin: 'Zeno of Elea',
    year: 'MÖ 450'
  },
  {
    id: 'grandfather-paradox',
    title: "Dede Paradoksu",
    titleEn: "Grandfather Paradox",
    description: "Zamanda geriye gidip dedeni öldürürsen, sen hiç doğmamış olmazsın. Peki o zaman cinayeti kim işledi?",
    explanation: "Dede paradoksu, zaman yolculuğunun mantıksal bir çelişkisidir. Eğer bir zaman yolcusu geçmişe giderek büyükbabasını öldürürse, kendi doğumu engellenmiş olur. Bu durumda zaman yolcusu hiç var olmamış olur ve büyükbabasını öldüremez. Bu paradoks, zaman yolculuğunun imkansız olduğunu veya paralel evrenlerin var olduğunu düşündürmektedir. Stephen Hawking bu paradoksu 'kronoloji koruma hipotezi' ile açıklamaya çalışmıştır.",
    category: 'time',
    image: 'https://kimi-web-img.moonshot.cn/img/res.cloudinary.com/ba90965d8ff8fa9dc9c14e8f109ffc84ed2c389e.jpg',
    difficulty: 'medium',
    origin: 'René Barjavel',
    year: '1943'
  },
  {
    id: 'liar-paradox',
    title: "Yalancının Paradoksu",
    titleEn: "Liar Paradox",
    description: "'Bu cümle yanlıştır.' Eğer bu doğruysa yanlıştır, eğer yanlışsa doğrudur.",
    explanation: "Yalancının paradoksu, Epimenides'in (MÖ 6. yüzyıl) 'Tüm Giritliler yalancıdır' sözüne dayanır. Eubulides tarafından daha net bir şekilde formüle edilmiştir. Bu paradoks, kendine atıfta bulunan ifadelerin doğruluk değerini sorgular. Bertrand Russell bu paradoksu küme teorisine uygulayarak 'Russell Paradoksu'nu oluşturmuştur: 'Kendini içermeyen tüm kümelerin kümesi, kendini içerir mi?' Bu paradoks, modern mantık ve küme teorisinin temellerini sarsmıştır.",
    category: 'logic',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80',
    difficulty: 'hard',
    origin: 'Eubulides of Miletus',
    year: 'MÖ 4. yüzyıl'
  },
  {
    id: 'theseus-ship',
    title: "Theseus'un Gemisi",
    titleEn: "Ship of Theseus",
    description: "Bir geminin tüm parçaları değiştirilirse, bu hâlâ aynı gemi midir?",
    explanation: "Theseus'un gemisi paradoksu, kimlik ve süreklilik kavramlarını sorgular. Plutarch tarafından kaydedilen bu düşünce deneyinde, Theseus'un gemisi o kadar çok tamir görmüştür ki orijinal parçalarından hiçbiri kalmamıştır. Soru şudur: Bu hâlâ aynı gemi midir? Daha da karmaşıklaştırmak gerekirse, eski parçalarla yeni bir gemi inşa edilirse hangisi gerçek Theseus'un gemisidir? Bu paradoks, nesne kimliği ve bireysellik felsefesinde önemli bir yere sahiptir.",
    category: 'philosophy',
    image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=800&q=80',
    difficulty: 'medium',
    origin: 'Plutarch',
    year: 'MÖ 75'
  },
  {
    id: 'monty-hall',
    title: "Monty Hall Problemi",
    titleEn: "Monty Hall Problem",
    description: "Ü kapıdan birini seçtin. Sunucu boş bir kapıyı açtı. Seçimini değiştirmeli misin?",
    explanation: "Monty Hall problemi, 1975'te Steve Selvin tarafından ortaya atılmış bir olasılık bulmacasıdır. Üç kapıdan birinin arkasında araba, diğerlerinin arkasında keçi vardır. Yarışmacı bir kapı seçer, sunucu (arabayı bildiği için) boş bir kapıyı açar ve yarışmacıya seçimini değiştirme şansı verir. Seçimi değiştirmek kazanma olasılığını 1/3'ten 2/3'e çıkarır. Bu sonuç sezgiye aykırıdır ve birçok matematikçiyi şaşırtmıştır. Açıklama: İlk seçimde yanlış kapıyı seçme olasılığı 2/3'tür ve sunucu boş kapıyı açınca bu olasılık kalan kapıya aktarılır.",
    category: 'mathematics',
    image: 'https://images.unsplash.com/photo-1518893063132-36e46dbe2428?w=800&q=80',
    difficulty: 'medium',
    origin: 'Steve Selvin',
    year: '1975'
  },
  {
    id: 'fermi-paradox',
    title: "Fermi Paradoksu",
    titleEn: "Fermi Paradox",
    description: "Evrende milyarlarca galaksi var. Neden hâlâ hiçbir uzaylıyla karşılaşmadık?",
    explanation: "Fermi paradoksu, 1950'de fizikçi Enrico Fermi tarafından ortaya atılmıştır. Evrende milyarlarca yıldız ve galaksi olmasına rağmen, neden uzaylı uygarlıklarından hiçbir iz bulamadığımızı sorgular. Drake Denklemi, galaksideki uygarlık sayısını tahmin etmeye çalışır. Olası çözümler: Büyük Filtre (uygarlıklar yok oluyor), uzaylılar bizi gizliyor, iletişim teknolojileri farklı, veya gerçekten yalnızız. Bu paradoks, SETI projesi ve uzay araştırmalarının temel motivasyonlarından biridir.",
    category: 'physics',
    image: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=800&q=80',
    difficulty: 'hard',
    origin: 'Enrico Fermi',
    year: '1950'
  },
  {
    id: 'olbers-paradox',
    title: "Olbers Paradoksu",
    titleEn: "Olbers' Paradox",
    description: "Evrende sonsuz yıldız varsa, gece gökyüzü neden karanlık?",
    explanation: "Olbers paradoksu, 1823'te Heinrich Olbers tarafından formüle edilmiştir. Eğer evren sonsuz, statik ve yıldızlarla doluysa, her bakış doğrultusunda eninde sonunda bir yıldızın yüzeyine ulaşılmalıdır. Bu durumda gece gökyüzü, bir yıldızın yüzeyi kadar parlak olmalıdır. Ancak gece gökyüzü karanlıktır. Bu paradoksun çözümü, evrenin genişlediğini ve sonlu yaşta olduğunu gösterir. Uzak yıldızların ışığı henüz bize ulaşmamıştır ve evrenin genişlemesi nedeniyle kırmızıya kayarak görünmez hale gelmektedir.",
    category: 'physics',
    image: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=800&q=80',
    difficulty: 'medium',
    origin: 'Heinrich Olbers',
    year: '1823'
  },
  {
    id: 'twin-paradox',
    title: "İkizler Paradoksu",
    titleEn: "Twin Paradox",
    description: "Bir ikiz uzaya gider, diğeri Dünya'da kalır. Dönen ikiz daha genç midir?",
    explanation: "İkizler paradoksu, Einstein'ın özel görelilik teorisinin bir sonucudur. Işık hızına yakın hareket eden bir ikiz, Dünya'da kalan ikizine göre daha yavaş yaşlanır. Paradoks şudur: Uzaydaki ikiz, Dünya'nın kendisinden uzaklaştığını da söyleyebilir, o zaman Dünya'daki ikiz daha genç olmalıdır? Çözüm: Uzay ikizi hızlanma ve yavaşlama yapar (ivmeli referans sistemi), bu asimetri onun daha genç kalmasını sağlar. Bu etki GPS uydularında düzeltilmektedir.",
    category: 'physics',
    image: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800&q=80',
    difficulty: 'hard',
    origin: 'Albert Einstein',
    year: '1911'
  },
  {
    id: 'russell-paradox',
    title: "Russell Paradoksu",
    titleEn: "Russell's Paradox",
    description: "Kendini içermeyen tüm kümelerin kümesi, kendini içerir mi?",
    explanation: "Bertrand Russell, 1901'de küme teorisinde bu paradoksu keşfetmiştir. 'R = {x | x ∉ x}' kümesini düşünün. Eğer R ∈ R ise, tanımına göre R ∉ R olmalıdır. Eğer R ∉ R ise, tanımına göre R ∈ R olmalıdır. Bu çelişki, Frege'nin mantık sistemini çökertmiş ve Russell ile Whitehead'in Principia Mathematica'da tip teorisini geliştirmesine yol açmıştır. Modern küme teorisi, 'düzenli küme' aksiyomu ile bu paradoksu önler.",
    category: 'mathematics',
    image: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&q=80',
    difficulty: 'hard',
    origin: 'Bertrand Russell',
    year: '1901'
  },
  {
    id: 'sorites-paradox',
    title: "Kum Yığını Paradoksu",
    titleEn: "Sorites Paradox",
    description: "Bir kum tanesi yığın değildir. Peki kaçıncı tane yığın yapar?",
    explanation: "Sorites paradoksu (Yunanca 'yığın'), Eubulides tarafından ortaya atılmıştır. Bir kum tanesi bir yığın değildir. Bir yığın olmayan şeye bir kum tanesi eklemek yığın yapmaz. Bu süreç devam ederse, hiçbir zaman bir kum yığını oluşturulamaz. Bu paradoks, 'belirsizlik' ve 'sınır çizgisi' problemlerini gösterir. Fuzzy logic (bulanık mantık) bu tür problemleri ele almak için geliştirilmiştir. Paradoks, dilin ve kavramların kesin sınırlarının olmadığını gösterir.",
    category: 'logic',
    image: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?w=800&q=80',
    difficulty: 'easy',
    origin: 'Eubulides of Miletus',
    year: 'MÖ 4. yüzyıl'
  },
  {
    id: 'buridan-ass',
    title: "Buridan'ın Eşeği",
    titleEn: "Buridan's Ass",
    description: "İki aynı yem arasında kalan eşek, karar veremeyerek açlıktan ölür mü?",
    explanation: "Buridan'ın eşeği, Jean Buridan tarafından 14. yüzyılda ortaya atılmış bir düşünce deneyidir. Tamamen rasyonel bir eşek, iki eşit uzaklıkta ve eşit cazibede yem arasında karar veremez ve açlıktan ölür. Bu paradoks, rasyonel karar vermenin sınırlarını ve özgür irade kavramını sorgular. Aristoteles benzer bir örnek vermiştir (açlıktan ölen adam). Modern nörobilim, kararsızlıkta 'rastgele' nöronal süreçlerin devreye girdiğini göstermektedir.",
    category: 'philosophy',
    image: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?w=800&q=80',
    difficulty: 'easy',
    origin: 'Jean Buridan',
    year: '1340'
  },
  {
    id: 'unexpected-hanging',
    title: "Beklenmedik İdam",
    titleEn: "Unexpected Hanging Paradox",
    description: "'İdam hafta içi bir gün ve beklenmedik bir gün olacak.' Mahkum bunun imkansız olduğunu kanıtlar, ama...",
    explanation: "Beklenmedik idam paradoksu, bir mahkuma 'hafta içi bir gün ve sizin için sürpriz olacak bir günde asılacaksınız' denir. Mahkum şöyle düşünür: Cuma günü olamaz, çünkü Perşembe akşamına kadar asılmazsam Cuma olduğunu bilirim. Perşembe de olamaz, çünkü Çarşamba akşamına kadar asılmazsam Perşembe veya Cuma olduğunu bilirim (Cuma'yı eledik). Bu indüksiyonla hiçbir gün olamaz. Ancak Çarşamba asılırsa gerçekten de sürpriz olur. Bu paradoks, 'bilmek' ve 'beklemek' kavramlarını sorgular.",
    category: 'logic',
    image: 'https://images.unsplash.com/photo-1505664194779-8beaceb93744?w=800&q=80',
    difficulty: 'hard',
    origin: 'D. J. O\'Connor',
    year: '1948'
  },
  {
    id: 'arrow-paradox',
    title: "Ok Paradoksu",
    titleEn: "Arrow Paradox",
    description: "Zeno'ya göre uçan bir ok aslında hiç hareket etmez. Nasıl mı?",
    explanation: "Zeno'nun ok paradoksu, hareketin sürekliliğini sorgular. Zeno'ya göre, zaman 'an'lardan oluşur ve 'an' bölünemez. Bir ok herhangi bir 'an'da belirli bir yerdedir. Eğer bir 'an'da yer değiştirmiyorsa, o 'an'da hareketsizdir. Tüm 'an'larda hareketsizse, genel olarak hareketsizdir. Bu paradoks, süreklilik ve anlık hız kavramlarını sorgular. Modern fizikte, anlık hız limit kavramıyla tanımlanır ve hareket, konumun zamanla değişimi olarak anlaşılır.",
    category: 'physics',
    image: 'https://images.unsplash.com/photo-1514539079130-25950c84af65?w=800&q=80',
    difficulty: 'medium',
    origin: 'Zeno of Elea',
    year: 'MÖ 450'
  },
  {
    id: 'bootstrap-paradox',
    title: "Bootstrap Paradoksu",
    titleEn: "Bootstrap Paradox",
    description: "Zamanda geriye gidip Shakespeare'e onun oyunlarını verirsen, oyunları kim yazmış olur?",
    explanation: "Bootstrap paradoksu (ontolojik paradoks), zaman yolculuğunda nedensellik döngülerini sorgular. Bir zaman yolcusu geçmişe gidip Shakespeare'e onun oyunlarını verir. Shakespeare oyunları yazar ve bunlar yüzyıllar boyunca aktarılır. Zaman yolcusu bu oyunları alıp geçmişe götürür. Peki oyunların orijinal yazarı kimdir? Bu paradoks, 'bilgi'nin veya 'nesne'nin nedensel bir kökene sahip olmadan var olabileceğini düşündürür. Doctor Who dizisinde bu paradoks sıkça işlenir.",
    category: 'time',
    image: 'https://images.unsplash.com/photo-1505664194779-8beaceb93744?w=800&q=80',
    difficulty: 'medium',
    origin: 'Robert Heinlein',
    year: '1941'
  },
  {
    id: 'simpson-paradox',
    title: "Simpson Paradoksu",
    titleEn: "Simpson's Paradox",
    description: "Bir ilaç hem erkeklerde hem kadınlarda daha iyi sonuç veriyor, ama genel olarak daha kötü!",
    explanation: "Simpson paradoksu, 1951'de Edward Simpson tarafından tanımlanmış bir istatistiksel paradokstur. Bir ilaç hem erkeklerde hem kadınlarda diğerinden daha iyi sonuç verirken, toplamda daha kötü sonuç verebilir. Bu, gruplar arasındaki boyut farklılıklarından kaynaklanır. Örnek: Üniversite kabullerinde her bölümde kadınların kabul oranı daha yüksek olabilir, ama genel kabul oranı erkeklerin lehine olabilır. Bu paradoks, istatistiksel analizde 'saklı değişken' problemini gösterir.",
    category: 'mathematics',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
    difficulty: 'medium',
    origin: 'Edward Simpson',
    year: '1951'
  },
  {
    id: 'crocodile-dilemma',
    title: "Timsah İkilemi",
    titleEn: "Crocodile Dilemma",
    description: "Timsah: 'Çocuğunu doğru tahmin edersen geri veririm.' Anne: 'Çocuğumu yiyeceksin.'",
    explanation: "Timsah ikilemi, Antik Yunan'dan beri bilinen bir mantık paradoksudur. Bir timsah bir çocuk kaçırır ve annesine der ki: 'Çocuğunu ne yapacağımı doğru tahmin edersen geri veririm.' Anne 'Çocuğumu yiyeceksin' der. Eğer timsah çocuğu yerse, anne doğru tahmin etmiş olur ve timsah çocuğu geri vermelidir. Eğer geri verirse, anne yanlış tahmin etmiş olur ve timsah çocuğu yemelidir. Bu paradoks, kendine atıfta bulunan koşullu ifadelerin problemlerini gösterir.",
    category: 'logic',
    image: 'https://images.unsplash.com/photo-1522606560942-8367d3c0ad53?w=800&q=80',
    difficulty: 'easy',
    origin: 'Ancient Greece',
    year: 'MÖ 5. yüzyıl'
  },
  {
    id: 'preface-paradox',
    title: "Önsöz Paradoksu",
    titleEn: "Preface Paradox",
    description: "Yazar: 'Kitabımdaki tüm iddialar doğrudur, ama yine de bazı hatalar olabilir.'",
    explanation: "Önsöz paradoksu, bilgi ve inanç arasındaki ilişkiyi sorgular. Bir yazar kitabında 'Bu kitaptaki tüm iddialar doğrudur' der, ama önsözde 'Elbette bazı hatalar olabilir' der. Her iki ifade de makul görünür, ama birlikte çelişkilidir. Eğer tüm iddialar doğruysa, 'bazı hatalar var' iddiası yanlıştır. Eğer bazı halar varsa, 'tüm iddialar doğru' iddiası yanlıştır. Bu paradoks, 'düşünceli inanç' ve 'otorite' kavramlarını sorgular.",
    category: 'philosophy',
    image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=800&q=80',
    difficulty: 'easy',
    origin: 'D. C. Makinson',
    year: '1965'
  }
];

// Günlük paradoks seçimi için fonksiyon
export function getDailyParadox(): Paradox {
  const today = new Date();
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
  const index = dayOfYear % paradoxes.length;
  return {
    ...paradoxes[index],
    date: today.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })
  };
}

// Rastgele paradoks önerisi
export function getRandomParadox(excludeId?: string): Paradox {
  const filtered = excludeId ? paradoxes.filter(p => p.id !== excludeId) : paradoxes;
  return filtered[Math.floor(Math.random() * filtered.length)];
}

// Kategoriye göre filtreleme
export function getParadoxesByCategory(category: Category): Paradox[] {
  if (category === 'all') return paradoxes;
  return paradoxes.filter(p => p.category === category);
}

// Arama fonksiyonu
export function searchParadoxes(query: string): Paradox[] {
  const lowercaseQuery = query.toLowerCase();
  return paradoxes.filter(p => 
    p.title.toLowerCase().includes(lowercaseQuery) ||
    p.description.toLowerCase().includes(lowercaseQuery) ||
    p.explanation.toLowerCase().includes(lowercaseQuery)
  );
}
